#!/bin/bash

# Add footer to all pages
echo "🦶 Adding footer to all pages..."

# Footer HTML for root level pages
FOOTER_ROOT='  <!-- Footer -->
  <footer class="footer">
    <div class="container">
      <div class="footer-content">
        <div class="footer-section">
          <div class="footer-logo">
            <img src="assets/images/choco-logo.png" alt="Chocolate & Art Show logo" width="40" height="40">
            <span>Chocolate & Art Show</span>
          </div>
          <p class="footer-tagline">Where art meets chocolate, and creativity flows.</p>
        </div>
        
        <div class="footer-section">
          <h3>Event Info</h3>
          <ul>
            <li>September 18-19, 2025</li>
            <li>Lofty Spaces, Dallas</li>
            <li>21+ Event</li>
            <li>Doors: 7:00 PM</li>
          </ul>
        </div>
        
        <div class="footer-section">
          <h3>Quick Links</h3>
          <ul>
            <li><a href="tickets.html">Buy Tickets</a></li>
            <li><a href="artists/index.html">Meet Artists</a></li>
            <li><a href="schedule.html">Event Schedule</a></li>
            <li><a href="gallery.html">Photo Gallery</a></li>
          </ul>
        </div>
        
        <div class="footer-section">
          <h3>Get Involved</h3>
          <ul>
            <li><a href="mailto:ChocolateandArt@gmail.com?subject=Artist Application">Apply as Artist</a></li>
            <li><a href="mailto:ChocolateandArt@gmail.com?subject=Vendor Application">Apply as Vendor</a></li>
            <li><a href="mailto:ChocolateandArt@gmail.com?subject=Musician Application">Apply as Musician</a></li>
            <li><a href="contact.html">Contact Us</a></li>
          </ul>
        </div>
      </div>
      
      <div class="footer-bottom">
        <div class="footer-legal">
          <p>&copy; 2025 Chocolate & Art Show. All rights reserved.</p>
          <p>An immersive experience celebrating art, music, and artisan chocolate.</p>
        </div>
        <div class="footer-social">
          <a href="mailto:ChocolateandArt@gmail.com" aria-label="Email us">
            <span>📧</span>
          </a>
          <a href="play/kusama/index.html" aria-label="Interactive playground">
            <span>🎨</span>
          </a>
        </div>
      </div>
    </div>
  </footer>'

# Footer HTML for artists subdirectory
FOOTER_ARTISTS='  <!-- Footer -->
  <footer class="footer">
    <div class="container">
      <div class="footer-content">
        <div class="footer-section">
          <div class="footer-logo">
            <img src="../assets/images/choco-logo.png" alt="Chocolate & Art Show logo" width="40" height="40">
            <span>Chocolate & Art Show</span>
          </div>
          <p class="footer-tagline">Where art meets chocolate, and creativity flows.</p>
        </div>
        
        <div class="footer-section">
          <h3>Event Info</h3>
          <ul>
            <li>September 18-19, 2025</li>
            <li>Lofty Spaces, Dallas</li>
            <li>21+ Event</li>
            <li>Doors: 7:00 PM</li>
          </ul>
        </div>
        
        <div class="footer-section">
          <h3>Quick Links</h3>
          <ul>
            <li><a href="../tickets.html">Buy Tickets</a></li>
            <li><a href="index.html">Meet Artists</a></li>
            <li><a href="../schedule.html">Event Schedule</a></li>
            <li><a href="../gallery.html">Photo Gallery</a></li>
          </ul>
        </div>
        
        <div class="footer-section">
          <h3>Get Involved</h3>
          <ul>
            <li><a href="mailto:ChocolateandArt@gmail.com?subject=Artist Application">Apply as Artist</a></li>
            <li><a href="mailto:ChocolateandArt@gmail.com?subject=Vendor Application">Apply as Vendor</a></li>
            <li><a href="mailto:ChocolateandArt@gmail.com?subject=Musician Application">Apply as Musician</a></li>
            <li><a href="../contact.html">Contact Us</a></li>
          </ul>
        </div>
      </div>
      
      <div class="footer-bottom">
        <div class="footer-legal">
          <p>&copy; 2025 Chocolate & Art Show. All rights reserved.</p>
          <p>An immersive experience celebrating art, music, and artisan chocolate.</p>
        </div>
        <div class="footer-social">
          <a href="mailto:ChocolateandArt@gmail.com" aria-label="Email us">
            <span>📧</span>
          </a>
          <a href="../play/kusama/index.html" aria-label="Interactive playground">
            <span>🎨</span>
          </a>
        </div>
      </div>
    </div>
  </footer>'

# Add footer to root level pages
for file in tickets.html gallery.html schedule.html faq.html contact.html; do
    if [ -f "$file" ]; then
        echo "  Adding footer to $file..."
        # Find the line with </main> and add footer before the scripts
        sed -i '' "/  <\/main>/a\\
$FOOTER_ROOT\\
" "$file"
    fi
done

# Add footer to artists pages
for file in artists/*.html; do
    if [ -f "$file" ]; then
        echo "  Adding footer to $file..."
        # Find the line with </main> and add footer before the scripts
        sed -i '' "/  <\/main>/a\\
$FOOTER_ARTISTS\\
" "$file"
    fi
done

echo "✅ Footer added to all pages!"
EOF
