#!/bin/bash

# Update all email addresses to info@chocolateandartshow.com
echo "📧 Updating all email addresses to info@chocolateandartshow.com..."

# Update all HTML files
for file in *.html artists/*.html play/kusama/*.html; do
    if [ -f "$file" ]; then
        echo "  Updating $file..."
        # Replace all instances of the old email
        sed -i '' 's/ChocolateandArt@gmail\.com/info@chocolateandartshow.com/g' "$file"
    fi
done

# Update JavaScript files
for file in assets/js/*.js; do
    if [ -f "$file" ]; then
        echo "  Updating $file..."
        sed -i '' 's/ChocolateandArt@gmail\.com/info@chocolateandartshow.com/g' "$file"
    fi
done

# Update README if it exists
if [ -f "README.md" ]; then
    echo "  Updating README.md..."
    sed -i '' 's/ChocolateandArt@gmail\.com/info@chocolateandartshow.com/g' "README.md"
fi

echo "✅ Email addresses updated!"
echo ""
echo "📋 Summary of changes:"
echo "- All ChocolateandArt@gmail.com → info@chocolateandartshow.com"
echo "- Removed 'Musicians apply' buttons from application sections"
echo "- Simplified contact page to only show General Inquiries"
EOF
